#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BPTradeReview[] cacheBPTradeReview;

		
		public BPTradeReview BPTradeReview()
		{
			return BPTradeReview(Input);
		}


		
		public BPTradeReview BPTradeReview(ISeries<double> input)
		{
			if (cacheBPTradeReview != null)
				for (int idx = 0; idx < cacheBPTradeReview.Length; idx++)
					if ( cacheBPTradeReview[idx].EqualsInput(input))
						return cacheBPTradeReview[idx];
			return CacheIndicator<BPTradeReview>(new BPTradeReview(), input, ref cacheBPTradeReview);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BPTradeReview BPTradeReview()
		{
			return indicator.BPTradeReview(Input);
		}


		
		public Indicators.BPTradeReview BPTradeReview(ISeries<double> input )
		{
			return indicator.BPTradeReview(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BPTradeReview BPTradeReview()
		{
			return indicator.BPTradeReview(Input);
		}


		
		public Indicators.BPTradeReview BPTradeReview(ISeries<double> input )
		{
			return indicator.BPTradeReview(input);
		}

	}
}

#endregion
